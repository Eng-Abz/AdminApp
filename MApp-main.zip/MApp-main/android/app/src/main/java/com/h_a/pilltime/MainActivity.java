package com.h_a.pilltime;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
