import welcome from './welcome.png'
import friends from './friends.png'
import pills from './pills.png';
import rocket from './rocket.png'



const welcomeImages= {
    welcome: welcome,
    friends: friends,
    pills: pills,
    rocket: rocket,
 
  }

export default welcomeImages;