import {  IonItem,IonList, IonLabel, IonSearchbar } from "@ionic/react";
import  { useState } from "react";
import './SearchBar.css'



function SearchBar({medications}) {

  const [filteredData, setFilteredData] = useState([]);
  const [wordEntered, setWordEntered] = useState("");

  const handleFilter = (detail) => {
    const searchWord = detail.target.value;
    setWordEntered(searchWord);
    const newFilter = medications.filter((medication) => {
      return medication.name.toLowerCase().includes(searchWord.toLowerCase());
    });

    if (searchWord === "") {
      setFilteredData([]);
    } else {
      setFilteredData(newFilter);
    }
  };


  return (
    <div>
      <div>
        <div>
            <IonSearchbar
             showCancelButton="never"
             class="custom"
             onIonChange={handleFilter}
             ></IonSearchbar>
        </div>
      </div>
      {filteredData.length != 0 && (
        <IonList>
          {filteredData.map((medication) => {
            return (
              <IonItem key={medication.id} button>
                <IonLabel>
                    {medication.name}
                </IonLabel>
              </IonItem>
            );
          })}
        </IonList>
      )}
    </div>
  );
}

export default SearchBar;
