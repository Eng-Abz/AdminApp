import { IonAvatar, IonContent, IonLoading, IonPage } from '@ionic/react';
import React, { useEffect, useRef, useState } from 'react';
import { IonGrid, IonRow, IonCol } from '@ionic/react';

import { IonItem, IonLabel, IonInput, IonButton, IonAlert } from '@ionic/react';


import { useAuth } from '../auth';
import { Redirect } from 'react-router';
import { signup, auth, saveFile, createUserCollection } from '../firebase';
import "./auth.css";
import { updateProfile } from 'firebase/auth';


function validateEmail(email: string) {
  const re = /^((?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\]))$/;
  return re.test(String(email).toLowerCase());
}

const Register: React.FC = () => {
  const {loggedIn} = useAuth();
  const [text, setText] = useState<string>("");
  const [age, setAge] = useState<string>("");
  const [email, setEmail] = useState<string>("");
  const [Image, setImage] = useState<string>("https://ionicframework.com/docs/demos/api/avatar/avatar.svg");
  const [picURL, setPicUrl] = useState<any>();
  const [password, setPassword] = useState<string>("");
  const [confirmpassword, setConfirmpassword] = useState<string>("");
  const [status, setStatus] = useState({ loading: false, error: false});
  const [message, setMessage] = useState<string>("");


  const imgInputRef = useRef<any>();


  const handleFile = (event: React.ChangeEvent<HTMLInputElement>) => {
    const length = event.target.files?.length;
    if(length!== undefined){
      if ( length > 0){
        const file:any = event.target.files?.item(0);
        const picUrl:string= URL.createObjectURL(file);
        setImage(picUrl);
      }
    }
  };


  const handleRegister = async () => {
  if (email === "" || password === "" || confirmpassword === "") {
    setMessage("Please enter All Field");
    setStatus({loading:false, error:true});
    return;
    }

    if (text === "") { // when name field is empty
    setMessage("Please enter Full name");
    setStatus({loading:false, error:true});
    return;
    }
    // Email entry conditions
    if (!email || email == null || validateEmail(email) === false) {
      setMessage("Please enter a valid email");
      setStatus({loading:false, error:true});
      return;
  }
    if ((password.length < 8)) { // Checks if the password length is less than 8 and then proceed with other conditions in the else statement
        setMessage("Your password must be at least 8 characters");
        setStatus({loading:false, error:true});
        return;
    }

   if (!(password.match(/[A-Z]+/g) && password.match(/[a-z]+/g) && password.match(/[0-9]+/g))){ // Checks if the password has uppercase letters and lowercase letters and numbers
      setMessage("Your password must be at least 8 characters including a lowercase letter, an uppercase letter, and a number");
      setStatus({loading:false, error:true});
      return;
  }
  if (password !== confirmpassword){
    setMessage("Passwords do NOT match");
      setStatus({loading:false, error:true});
  }

  try {
    setStatus({loading:true, error:false});
     await signup(email, password);

  } catch (error) {
    setMessage("The email address is already registered");
    setStatus({loading:false, error:true});
    return;
  }

  const user = auth.currentUser;
  if(user?.uid){
    await saveFile(Image, user.uid);
    createUserCollection(text, age, user.uid, email);
}
  if(user !== null){
    updateProfile(user, {
    displayName: text
  })
}
  };

  if(loggedIn){
    return <Redirect to="/my/home" />
  }

  return (
    <IonPage>
      <IonContent fullscreen className="ion-padding ion-text-center">
            <IonAlert
                isOpen={status.error}
                onDidDismiss={() => setStatus({loading:false,error:false})}
                cssClass="my-custom-class"
                header={"Error!"}
                message={message}
                buttons={["Dismiss"]}
            />
        <IonGrid>
        <IonRow>
        <IonCol  size-md="6">
            <br/>
          </IonCol>
          <IonCol  size-md="6">
            <IonAvatar className='logo'>
            <img alt="Profile Silhoutte" src={Image} onClick={()=> imgInputRef.current.click()}/>
            </IonAvatar>
          </IonCol>
          <IonCol  size-md="12">
            <br/>
          </IonCol>
        </IonRow>
            <input
                type="file"
                accept="image/*"
                ref={imgInputRef}
                onChange={handleFile}
                hidden
                />
          <IonRow>
            <IonCol>
            <IonItem>
            <IonLabel position="floating" >Name</IonLabel>
            <IonInput
                type="text"
                value={text}

                placeholder="Enter Full name"
                onIonChange={(e) => setText(e.detail.value!)}
                >
            </IonInput>
            </IonItem>
            </IonCol>
          </IonRow>
          <IonRow>
            <IonCol>
            <IonItem>
            <IonLabel position="floating" >Age</IonLabel>
            <IonInput
                type="number"
                value={age}

                placeholder="Enter Age"
                onIonChange={(e) => setAge(e.detail.value!)}
                >
            </IonInput>
            </IonItem>
            </IonCol>
          </IonRow>

          <IonRow>
            <IonCol>
            <IonItem>
            <IonLabel position="floating" >Email</IonLabel>
            <IonInput
                type="email"
                value={email}
                placeholder="example@mail.com"
                required
                onIonChange={(e) => setEmail(e.detail.value!)}
                >

            </IonInput>
            </IonItem>
            </IonCol>
          </IonRow>

          <IonRow>
            <IonCol>
            <IonItem>
              <IonLabel position="floating" >Password</IonLabel>
              <IonInput
                type="password"
                value={password}
                placeholder="Enter your password"
                required
                onIonChange={(e) => setPassword(e.detail.value!)}
                >
              </IonInput>
            </IonItem>
            </IonCol>
          </IonRow>

          <IonRow>
            <IonCol>
            <IonItem>
              <IonLabel position="floating"> Confirm Password</IonLabel>
              <IonInput
                type="password"
                value={confirmpassword}
                placeholder="Confirm your password"
                required
                onIonChange={(e) => setConfirmpassword(e.detail.value!)}
                >
              </IonInput>
            </IonItem>
            </IonCol>
          </IonRow>
          <IonRow>
            <IonCol>
              <p style={{ fontSize: "small" }}>
                  By clicking Sign Up you agree to our <a href="#">Policy</a>
              </p>
              <IonButton expand="block" onClick={handleRegister}>Sign Up</IonButton>
              <p style={{ fontSize: "medium" }}>
                  You have an account? <a href="Login">Login!</a>
              </p>

            </IonCol>
          </IonRow>
        </IonGrid>
      <IonLoading isOpen = {status.loading}/>
    </IonContent>

    </IonPage>
  );
};

export default Register;
