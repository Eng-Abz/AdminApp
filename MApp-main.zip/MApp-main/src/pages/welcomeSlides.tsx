import React from 'react';
import { IonSlides, IonSlide, IonContent, IonButton, IonIcon, IonPage } from '@ionic/react';
import { arrowForward } from "ionicons/icons";

import "./welcomeSlides.css";
import welcomeImages from './WelcomePgae/welcomeImages';
// Optional parameters to pass to the swiper instance.
// See https://swiperjs.com/swiper-api for valid options.
const slideOpts = {
  initialSlide: 0,
  speed: 400
};

export const welcomeSlides: React.FC = () => (
  <IonPage>
    <IonContent>
      <IonSlides pager={true} options={slideOpts}>
            <IonSlide>
              <div className="slide">
                <img src={welcomeImages.welcome} />
                <h2>Welcome</h2>
                <p>
                <b>Whether it’s once per day or more often,</b> remembering to take your medications as intended is not always easy.
                </p>
              </div>
            </IonSlide>

            <IonSlide>
              <img src= {welcomeImages.pills} />
              <h2>What is Pill Time?</h2>
              <p>
                 Do you often forget to take your medicines? Or do you want to help your loved ones to remember their medication? Here is an easy pill reminder application for you. <b>Pill Time App</b> has been planned based on reviews of many other programs, as well as reviews of people using medicines, and is ready to help people of all ages.
              </p>
            </IonSlide>

            <IonSlide>
              <img src={welcomeImages.friends} />
              <h2>Add Friends!</h2>
              <p>
            <b>Pill Time</b> App is the easiest medication tracker. <b>Keep yourself and loved ones safe</b> and never forget to take your medicine again with Pill Time Medication Reminder.
              </p>
            </IonSlide>

            <IonSlide>
              <img src={welcomeImages.rocket} />
              <h2>Ready to go?</h2>
              <IonButton fill="clear" routerLink='./login'>Continue <IonIcon icon={arrowForward}></IonIcon></IonButton>
            </IonSlide>
          </IonSlides>
        </IonContent>
      </IonPage>
      );
      export default welcomeSlides;

