import welcome from './welcome.png'



const welcomeImages= {
    welcome: welcome,
 
  }

export default welcomeImages;