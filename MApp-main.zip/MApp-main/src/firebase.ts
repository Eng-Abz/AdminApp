import { initializeApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';
import { doc, getFirestore, setDoc } from 'firebase/firestore';
import { getDownloadURL, getStorage, ref, uploadBytes } from 'firebase/storage';
import { getAnalytics, logEvent } from "firebase/analytics";


const firebaseConfig = {

  apiKey: "AIzaSyBjVOv2pV-9CZ4ivrkMiG6FSSeNpIVF-x0",
  authDomain: "pill-time-905f0.firebaseapp.com",
  projectId: "pill-time-905f0",
  storageBucket: "pill-time-905f0.appspot.com",
  messagingSenderId: "838377202879",
  appId: "1:838377202879:web:0add95565eecf25f3c120a",
  measurementId: "G-3J4RTYSMWZ"
};


 export const app = initializeApp(firebaseConfig);
 export const auth = getAuth(app);
 export const db = getFirestore(app);
 export const storage = getStorage(app);
 export const analytics = getAnalytics();

 export function signup(email: string, password: string){
  logEvent(analytics,'signup', {createUserWithEmailAndPassword});
  return createUserWithEmailAndPassword(auth,email,password);
 }
 export function login(email: string, password: string){
   logEvent(analytics,'login', {signInWithEmailAndPassword});
   return signInWithEmailAndPassword(auth,email,password);
 }
 export async function saveFile(blobUrl:any, userId: string){
  const fileRef = ref(storage,`/Users/${userId}/photos/${Date.now()}`);
  const response = await fetch(blobUrl);
  const blob = await response.blob();
  uploadBytes(fileRef, blob).then((snapshot) => {
    const url:any = getDownloadURL(snapshot.ref).then((downloadurl) => {
      console.log('Uploaded a blob or file!', downloadurl)
      return downloadurl;
    });
  })
};

export async function createUserCollection(text:string, number: string, uid: string, email:string){

  logEvent(analytics,'Collection Created');
  const docData = {
    name: text,
    age: number,
    numMedication: 0,
    numFriends: 0,
    takenPills:0,
  }
  const togetherDocData = {
    email: email,
    id: uid
  }
  const setUserInfo = async () => {
  logEvent(analytics,'Collection Created');
  await setDoc(doc(db, `/Users/${uid}/profile/`,`profile`), docData);
  await setDoc(doc(db, `/User refrences/${email}/`), togetherDocData);
	}
  return setUserInfo();
};
