import { 
  IonButtons,
  IonButton,
  IonToolbar,
  IonContent,
  
} from '@ionic/react';

import { useRef } from 'react';
import MedicalList from '../pages/MedicalList/MedicalList';

const MedicalModal: React.FC<{  onDismiss: () => void;}> = props => {
  const modal = useRef<HTMLIonModalElement>(null);
  function dismiss() {
    modal.current?.dismiss();
}

  return(

         <IonContent>
           <IonToolbar color="primary">
             <IonButtons slot="end">
               <IonButton color="light" onClick={() => props.onDismiss()}>
                 Close
               </IonButton>
             </IonButtons>
           </IonToolbar>

           <MedicalList />


         </IonContent>
  );
}
export default MedicalModal;
