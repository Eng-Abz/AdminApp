import { useEffect, useRef, useState } from 'react';
import {
    IonSlides,
    IonSlide,
    IonContent,
    IonPage,
    IonHeader,
    IonToolbar,
    IonButton,
    IonButtons,
    IonBackButton,
    IonInput,
    IonItem ,
    IonList,
    IonSelect,
    IonSelectOption,
    IonDatetimeButton,
    IonModal,
    IonDatetime,
    IonGrid,
    IonRow,
    IonCol,
    IonRange,
    IonLabel,

   }
from '@ionic/react';
import "./FormPage.css";
import { doc, setDoc, Timestamp, updateDoc } from "firebase/firestore"; 

import {useForm} from "react-hook-form";
import { collection, getDocs, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../auth';
import notifications from './Notifications';

/*react hook form
import {FormProvider, useFormContext} from "react-hook-form";
import {ErrorMessage} from "@hookform/error-message"; */



const slideOpts = {
  initialSlide: 0,
  speed: 400
};

interface toMedications {
  id?: string,
name?: string,
liquid?: boolean,
  peanutAllergy?:boolean,
}
const FormPage: React.FC = () => {
  const { userId } = useAuth();  
    //saerch bar filteration section start
    const [filteredSearchBarDataData, setFilteredSearchBarDataData] = useState<toMedications[]>();
    const [wordEntered, setWordEntered] = useState<any>("");
    
    
    const handleSearchBarFilteration = (detail: any,medications: any) => {
      const searchWord = detail.target.value;
      setWordEntered(searchWord);
      setName(searchWord);
      const newFilter = medications.filter((medication: any) => {
        return medication.name.toLowerCase().includes(searchWord.toLowerCase());
      });
      if (searchWord === "") {
        setFilteredSearchBarDataData([])
      } else {
        setFilteredSearchBarDataData(newFilter);
      }
    };
    //saerch bar filteration section end
    //useState for profile start
      const [data, setData]= useState<number>(0)
      const profileRef = doc(db, `/Users/${userId}/profile/profile`);
      //useState for profile end
      
      useEffect(() => {
      onSnapshot(profileRef, (doc)=>{
          setData(doc.get("numMedication"))
        })
      }, []);

    const mySlides = useRef<any>(null);

    const { register, handleSubmit, formState: { errors } } = useForm();
    console.log(errors);

    useEffect(()=>{
        mySlides.current.lockSwipes(true);
    })

const next =async () => {
    await mySlides.current.lockSwipes(false);
    await mySlides.current.slideNext();
    await mySlides.current.lockSwipes(true);

}

const prev =async () => {
    await mySlides.current.lockSwipes(false);
    await mySlides.current.slidePrev();
    await mySlides.current.lockSwipes(true);


}

const [name, setName] = useState<string>('');
const [howOfften, setHowOfften] = useState<string>('');
const [perDay,setPerDay ] = useState<number>(1);
const [startDate,setStartDate ] = useState<string>('');
const [startDate2,setStartDate2 ] = useState<Date>();
const [instructed, setInstructed] = useState<number>(20);
const [intakeAdvice, setIntakeAdvice] = useState<string>('');

const onSubmit = async() =>{
  const docData = {
    name: name,
    howOfften: howOfften,
    perDay: perDay,
    instructed: instructed,
    intakeAdvice: intakeAdvice,
    taken: false,

  }
  const medicalHistory= {
    name: name,
  }
  

  await setDoc(doc(db, `/Users/${userId}/medications/`,`${name}`), docData);
  await setDoc(doc(db, `/Users/${userId}/midicalHistory/`,`${name}`), medicalHistory);

// the code bellow is to schedule notifications based on the prefrences the user added
  let d ="";
  let hours = 0;
  let minutes = 0;
  // convert startDate timestamp to hours and minutes as integers
  if (startDate !== undefined){
    d = startDate.split('T')[1];

    const h = d.split(':')[0];
    const m = d.split(':')[1];
    hours = parseInt(h);
    minutes = parseInt(m);
  }
  console.log('hour: ', hours, 'minute: ', minutes);
  // notifications in case of everyday
 
  switch(howOfften == "Every Day" ||howOfften == "Every Week" ) {
    case perDay == 1: 
    return notifications.scheduleEveryDay(hours,minutes, perDay,name);
    case perDay == 2: 
      hours+=6;
        return notifications.scheduleEveryDay(hours,minutes, perDay,name);
    case perDay == 3:
      hours+=3;
        return notifications.scheduleEveryDay(hours,minutes, perDay,name); 
    default:
      return notifications.scheduleEveryDay(hours,minutes, perDay,name);
  }


}



const [medications, setMedications] = useState<any[]>();

	
const medicationsRef = collection(db, '/Medications');
	
useEffect(()=>{
	const getMedications = async () => {
		const MedictionsData = await getDocs(medicationsRef)
		setMedications(MedictionsData.docs.map((doc)=>({...doc.data(), id: doc.id})))
	}
  getMedications()
	}, []);

  

    return (
        <IonPage>
          <IonHeader>
            <IonToolbar color="clear">
              <IonButtons slot="start">
                <IonBackButton color="primary" defaultHref="home" />
              </IonButtons>
            </IonToolbar>
          </IonHeader>


          <IonContent fullscreen className='ion-padding'>
          <IonGrid>
            <IonRow>
              <IonCol>
              <br />
              <br />
              </IonCol>
              <IonCol>
              <form onSubmit={handleSubmit(onSubmit)}>
              <IonSlides pager={true} options={slideOpts} ref={mySlides}>

              <IonSlide>
                <IonGrid>
                  <IonRow>
                  <IonCol>
                          <h1>What is the name of the medication?</h1>
                          <IonItem >                                        
                          <IonInput
                            // name='medicationName'
                              type='text'
                              value={wordEntered}
                              onIonChange={(details)=>handleSearchBarFilteration(details,medications)}
                              clearInput={true}
                              {...register("medicationName", {required: true})}
                          ></IonInput>
                          </IonItem>
                          {filteredSearchBarDataData?.length != 0 && (
                          <IonList>
                          {filteredSearchBarDataData?.map((medication) => {
                            return (
                              
                              <IonItem key={medication.id} >
                                <p style={{color: 'gray'}}>{medication.name}</p>                                              
                              </IonItem>
                            );
                          })}
                        </IonList>
                          )}
                          {errors.exampleRequired && <span>This field is required</span>}

                      </IonCol>
                      </IonRow>

                      <IonRow>
                      <IonCol>
                      <div className="form-footer">
                          <IonButton onClick={()=>next()}>Next</IonButton>
                      </div>

                      </IonCol>
                      </IonRow>
                  </IonGrid>
              </IonSlide>

              <IonSlide>
              <IonGrid>
                <IonRow>
                <IonCol>
                          <h1>How often will you take it?</h1>
                          <IonList>
                              <IonItem>
                                  <IonSelect
                                  //name='medicationPeriods'
                                  onIonChange={(e:any)=> setHowOfften(e.detail.value)}
                                  placeholder="Select" {...register("medicationPeriods", {required: true})}>
                                  <IonSelectOption value="Every Day">Every Day</IonSelectOption>
                                  <IonSelectOption value="Every Week">Every Week</IonSelectOption>
                                  </IonSelect>
                              </IonItem>
                          </IonList>
                          {errors.exampleRequired && <span>This field is required</span>}
                  </IonCol>
                  </IonRow>
                  <IonRow>
                  <IonCol>
                      <div className="form-footer">
                          <IonButton onClick={()=>prev()}>Prev</IonButton>
                          <IonButton onClick={()=>next()}>Next</IonButton>
                      </div>

                  </IonCol>
                  </IonRow>
                  </IonGrid>
              </IonSlide>

              <IonSlide>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                          <h1>How many time you will take it in a day?</h1>
                          <IonList  {...register("How-many-time", {required: true})}>
                              <IonRange
                              onIonChange={({detail}: any) => setPerDay(detail.value)}
                              pin={true}
                              max={3}
                              min={1}
                              
                              ></IonRange>
                              <div>
                                <IonLabel>per day: {perDay}</IonLabel>        
                              </div>
                          </IonList>
                          {errors.exampleRequired && <span>This field is required</span>}
                          </IonCol>
                        </IonRow>
                        <IonRow>
                          <IonCol>
                      <div className="form-footer">
                          <IonButton onClick={()=>prev()}>Prev</IonButton>
                          <IonButton onClick={()=>next()}>Next</IonButton>
                      </div>
                        </IonCol>
                      </IonRow>
                  </IonGrid>
              </IonSlide>
              <IonSlide>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                          <h1>When will you start taking it?</h1>
                              <IonDatetimeButton datetime="time"></IonDatetimeButton>
                                  <IonModal  keepContentsMounted={true}
                                  {...register("medicationStart", {required: true})}>
                                      <IonDatetime
                                      //name='medicationStart'
                                        id="datetime"
                                        onIonChange={(e : any)=> setStartDate(e.detail.value)}
                                        ></IonDatetime>
                                  </IonModal>
                              {errors.exampleRequired && <span>This field is required</span>}

                      </IonCol>
                    </IonRow>
                    <IonRow>
                      <IonCol>
                      <div className="form-footer">
                          <IonButton onClick={()=>prev()}>Prev</IonButton>
                          <IonButton onClick={()=>next()}>Next</IonButton>
                      </div>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </IonSlide>

              <IonSlide>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                          <h1>How many are you instructed to take?</h1>
                          <IonList {...register("medicationPills", {required: true})}>
                              <IonRange
                              onIonChange={(e: any)=> setInstructed( e.detail.value)}
                              pin={true}
                              max={80}
                              min={1}
                              ></IonRange>               
                              <div>
                                <IonLabel>per day: {instructed}</IonLabel>        
                              </div>               
                          </IonList>
                          {errors.exampleRequired && <span>This field is required</span>}

                      </IonCol>
                    </IonRow>
                    <IonRow>
                      <IonCol>
                      <div className="form-footer">
                          <IonButton onClick={()=>prev()}>Prev</IonButton>
                          <IonButton onClick={()=>next()}>Next</IonButton>
                      </div>
                    </IonCol>
                  </IonRow>
                </IonGrid>
              </IonSlide>

              <IonSlide>
                <IonGrid>
                  <IonRow>
                    <IonCol>
                          <h1>Have you got any intake advice?</h1>
                          <IonList>
                              <IonItem>
                                  <IonSelect
                                  //name='medicationAdvice'
                                    placeholder="Select"
                                    onIonChange={(e: any)=> setIntakeAdvice(e.detail.value)}
                                  {...register("medicationAdvice", {required: true})}>
                                  <IonSelectOption value="None">None</IonSelectOption>
                                  <IonSelectOption value="After meal">After meal</IonSelectOption>
                                  <IonSelectOption value="Before meal">Before meal</IonSelectOption>
                                  </IonSelect>
                              </IonItem>
                          </IonList>
                          {errors.exampleRequired && <span>This field is required</span>}
                      </IonCol>
                      </IonRow>
                    <IonRow>
                    <IonCol>
                      <div className="form-footer">
                          <IonButton onClick={()=>prev()}>Prev</IonButton>
                          {/*<IonButton type='submit'>Submit</IonButton>*/}
                          <IonButton onClick={onSubmit} routerLink="/my/home">Submit</IonButton>
                      </div>
                      </IonCol>
                    </IonRow>
                  </IonGrid>
              </IonSlide>
              </IonSlides>
              </form>
                  </IonCol>
                </IonRow>
              </IonGrid>
          </IonContent>


        </IonPage>
  );
};

export default FormPage ;
