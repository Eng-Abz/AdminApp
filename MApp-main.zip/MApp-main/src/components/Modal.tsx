import {
  IonButtons,
  IonButton,
  IonToolbar,
  IonContent,
  IonGrid,
  IonRow,
  IonCol,
  IonSearchbar,
  IonText,
} from '@ionic/react';

import React, { useState } from "react";

const Modal: React.FC<{  onDismiss: () => void;}> = props => {

  const [searchText, setSearchText] = useState('');



  return(

         <IonContent>
           <IonToolbar color="primary">
             <IonButtons slot="end">
               <IonButton color="light" onClick={() => props.onDismiss()}>
                 Close
               </IonButton>
             </IonButtons>
           </IonToolbar>
           <IonGrid>
              <IonRow class="ion-align-items-center">
                <IonCol>
                  <br/>
                </IonCol>
                <IonCol size="10"  class="ion-align-items-center">
                  <IonText color="Primary" className="ion-align-items-center ion-justify-content-center">
                     <h1>What is the name of the medication?</h1>
                   </IonText>
                </IonCol>
                <IonCol>
                  <br/>
                </IonCol>
              </IonRow>
              <IonRow>
                <IonCol>
                     <IonSearchbar
                     value={searchText} onIonChange={e => setSearchText(e.detail.value!)}
                     showCancelButton="never"
                     placeholder=""
                     animated
                     clearIcon="true"
                     color="light">
                     </IonSearchbar>
                </IonCol>
              </IonRow>
              <IonRow class="ion-align-items-center">
                <IonCol>
                  <br/>
                </IonCol>
                <IonCol size="3">
                  <IonButton routerLink='Modal3'>
                      Next

                  </IonButton>
                </IonCol>
                <IonCol>
                  <br/>
                </IonCol>
              </IonRow>
           </IonGrid>


         </IonContent>
  );
}
export default Modal;
