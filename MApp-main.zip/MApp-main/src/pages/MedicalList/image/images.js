import user from '../../../images/user.png'
import pill from '../../../images/pill.jpg'


const images= {
    user: user,
    pill: pill,
  }

export default images