import { Redirect, Route, Switch } from 'react-router-dom';

import { IonReactRouter } from '@ionic/react-router';
import {IonApp, IonLoading, setupIonicReact} from '@ionic/react';
import { AuthContext, useAuthInit } from './auth';


import AppTabs from './components/AppTabs';
import Login from './pages/Login';
import PageNotFound from './pages/PageNotFound';
import Register from './pages/Register';
import Welcome from './pages/welcomeSlides';

setupIonicReact({mode: 'ios'});

const App: React.FC = () => {
  const {loading , auth} = useAuthInit();
  if(loading){
    return <IonLoading isOpen/>
  }
return (
  <IonApp>
    <AuthContext.Provider value={auth}>
      <IonReactRouter>
        <Switch>
          <Route path="/my"> <AppTabs /> </Route>
      
          <Route exact path="/login"> <Login />  </Route>
          <Route exact path="/register"> <Register />   </Route>
          <Route exact path="/welcome"> <Welcome/>  </Route>
          <Route exact path="/" render={() => <Redirect to="/my/home" />} />

          <Route> <PageNotFound /> </Route>
        </Switch>
      </IonReactRouter>
    </AuthContext.Provider>
  </IonApp>
);
};

export default App;
