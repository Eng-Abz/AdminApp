import { IonButton, IonButtons, IonBackButton, IonCard, IonCardContent, IonCardHeader, IonCardSubtitle, IonCardTitle, IonCol, IonContent, IonGrid, IonHeader, IonIcon, IonPage, IonRow, IonText, IonToolbar, IonAvatar, IonItem } from '@ionic/react';
import { collection, doc, getDocs } from 'firebase/firestore';
import { arrowForward, bookmarkOutline, chatboxEllipsesOutline, medkitOutline, personAddOutline } from "ionicons/icons";

import { useEffect, useState } from 'react';
import { useAuth } from '../auth';


import { auth, db } from '../firebase';
import "./Profile.css";

const Profile = () => {
	const [name, setName] = useState<string>();
	const [image, setImage] = useState<string>("https://ionicframework.com/docs/demos/api/avatar/avatar.svg");
	

	const {userId} = useAuth();
	const user = auth.currentUser;
	const profileRef = doc(db, `/Users/${userId}/profile/profile`);
	useEffect(()=>{
		// const getProfile = async () => {
		// 	const profileData = await getDocs(profileRef)
		// 	setProfile(profileData.docs.map((doc):any=>({...doc.data(), id: doc.id})))
		// }

		 if(user?.photoURL){
			setImage(user.photoURL)
		 }
		 if(user?.displayName){
			setName(user.displayName)
		 }
		// getProfile();
		}, [user]);


	return (
		<IonPage className='Profile'>
			<IonHeader>
				<IonToolbar>
					<IonButtons slot="start">
						<IonButton>
							<IonBackButton color="primary" text="" />
						</IonButton>
					</IonButtons>
				</IonToolbar>
			</IonHeader>
			<IonContent>

				<div className='topHeader'></div>

				<IonGrid>
					<IonRow className="ion-justify-content-center">
						<IonCol size="12" className="ion-justify-content-center ion-align-items-center ion-text-center">
							<IonCard className='profileHeader'>

								<IonCardContent>

									<IonRow>
										<IonCol size="4">

											<img src={image} alt="avatar" className='avatar'/>

										</IonCol>

										<IonCol size="8">
											<IonRow className='profileInfo'>
												<IonCol size="12">
													<IonText color="dark" className='profileName'>
														<p>{name} Hi!</p>
													</IonText>

												</IonCol>
											</IonRow>

											<IonRow className='profileStats'>

												<IonCol className='profileStat'>

													{/* {profile?.map((profile:any) => {return( */}
													<IonCardTitle /*key={profile.id}*/>80</IonCardTitle>
														{/* )})} */}
													<IonCardSubtitle>Friends</IonCardSubtitle>
												</IonCol>

												
											</IonRow>
										</IonCol>
									</IonRow>

									<IonRow>
										<IonCol size="6">
											<IonButton fill="outline" expand="block" onClick={() => auth.signOut()}>
												Logout
											</IonButton>
										</IonCol>

										<IonCol size="6">
											<IonButton color="primary" expand="block" routerLink='/my/addFriends'>
												<IonIcon icon={ personAddOutline } size="small" />&nbsp;
												Friends
											</IonButton>
										</IonCol>
									</IonRow>
								</IonCardContent>
							</IonCard>
						</IonCol>
					</IonRow>

					<IonRow className='profileStatusContainer'>
						<IonCol size="12">
							<IonCard className='profileCard'>

								<IonCardHeader>
									<IonRow className='profileStatus'>
										<IonIcon icon={ chatboxEllipsesOutline } />
										<IonCardSubtitle>Hope you are having a great day!</IonCardSubtitle>
									</IonRow>
								</IonCardHeader>
								<IonCardContent>
									<IonText>
									{/*profile?.map((profile:any) => {
										return(
										<p>{profile.Status}</p>
										)})*/}
									</IonText>
								</IonCardContent>
							</IonCard>
						</IonCol>
					</IonRow>

					<IonRow>
						<IonCol size="6">
							<IonCard className='profileCard'>
								<IonCardContent>
									<IonIcon icon={ medkitOutline } />
									<IonCardTitle>80</IonCardTitle>
									<IonCardSubtitle>Pills</IonCardSubtitle>
								</IonCardContent>
							</IonCard>
						</IonCol>

						<IonCol size="6">
							<IonCard className='profileCard'>
								<IonCardContent>
									<IonIcon icon={ bookmarkOutline } />
												{/* {profile?.map((profile:any) => {return( */}
													<IonCardTitle>70{/*profile.numPills*/}</IonCardTitle>
													{/* )})} */}
													<IonCardSubtitle>Medications</IonCardSubtitle>
												
								</IonCardContent>
							</IonCard>
						</IonCol>
					</IonRow>

					<IonRow className='profileActionContainer'>
						<IonCol size="12">
							<IonCard className='profileActionCard'>
										<IonItem button routerLink='/my/editProfile' detailIcon=''>
								<IonCardContent>
									<IonRow className="ion-justify-content-between">
										<IonCardSubtitle>Edit Profile</IonCardSubtitle>
										<IonIcon icon={ arrowForward } />
									</IonRow>
								</IonCardContent>
							</IonItem>
							</IonCard>
						</IonCol>
					</IonRow>
				</IonGrid>

			</IonContent>
		</IonPage>
	);
};

export default Profile;
