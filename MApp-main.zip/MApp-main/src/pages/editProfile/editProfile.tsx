import { IonButton, IonButtons, IonBackButton, IonCard, IonCardContent, IonCardHeader, IonCardSubtitle, IonCardTitle, IonCol, IonContent, IonGrid, IonHeader, IonIcon, IonPage, IonRow, IonText, IonToolbar, IonAvatar, IonInput, IonItem, IonLabel, IonAlert, IonModal } from '@ionic/react';
import { OverlayEventDetail } from '@ionic/react/dist/types/components/react-component-lib/interfaces';
import { updatePassword, updateProfile } from 'firebase/auth';
import { collection, doc, getDocs, onSnapshot, setDoc } from 'firebase/firestore';

import { useEffect, useRef, useState } from 'react';
import { auth, db } from '../../firebase';

import "./editProfile.css";



const EditProfile: React.FC = () => {
  const imgInputRef = useRef<any>();
  const [profile, setProfile] = useState<any[]>();
  const [text, setText] = useState<string>("");
  const [age, setAge] = useState<string>("");
  const [email, setEmail] = useState<string>("");
  const [Image, setImage] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [confirmpassword, setConfirmpassword] = useState<string>("");
  const [status, setStatus] = useState({ loading: false, error: false});
  const [message, setMessage] = useState<string>("");
  
  const user = auth.currentUser;
  useEffect(()=>{
    if(user?.photoURL){
			setImage(user.photoURL)
		 }
     if(user?.displayName){
			setText(user.displayName)
		 }
     const profileRef = collection(db, `/Users/${user?.uid}/profile/`);
     const getProfile = async () => {
      onSnapshot(profileRef, (doc) => {
        setProfile(doc.docs.map(doc => ({...doc.data(), id: doc.id})))
    });}
      getProfile();
  }, []);

  const handleNameEdit = async () => {
    const docData = {
      name: text,
      age:profile?.map((profile:any) => {return(profile?.age)})
    }
    await setDoc(doc(db, `/Users/${user?.uid}/profile/`,`profile`), docData);
    if(user !== null){
      updateProfile(user, {
      displayName: text
    })
  }
  };
  const handleAgeEdit = async () => {
    const docData = {
      name: text,
      age: age
    }
    await setDoc(doc(db, `/Users/${user?.uid}/profile/`,`profile`), docData);
  };
  const handleFile = (event: React.ChangeEvent<HTMLInputElement>) => {
    const length = event.target.files?.length;
    if(length!== undefined){
      if ( length > 0){
        const file:any = event.target.files?.item(0);
        const picUrl:string= URL.createObjectURL(file);
        setImage(picUrl);
      }
    }
  };
  const handlePasswordChange = async () => {
	if (password === "" || confirmpassword === "") {
	  setMessage("Please enter All Field");
	  setStatus({loading:false, error:true});
	  return;
	  }
	  if ((password.length < 8)) { // Checks if the password length is less than 8 and then proceed with other conditions in the else statement
			setMessage("Your password must be at least 8 characters");
			setStatus({loading:false, error:true});
			return;
	  }
 
	 if (!(password.match(/[A-Z]+/g) && password.match(/[a-z]+/g) && password.match(/[0-9]+/g))){ // Checks if the password has uppercase letters and lowercase letters and numbers
		 setMessage("Your password must be at least 8 characters including a lowercase letter, an uppercase letter, and a number");
		 setStatus({loading:false, error:true});
		 return;
	}
	if (password !== confirmpassword){
	  setMessage("Passwords do NOT match");
		 setStatus({loading:false, error:true});
	}
 
  try {
    setStatus({loading:true, error:false});
    if(user){
      updatePassword(user, confirmpassword).then(() => {
        // Update successful.
      })
    }
  } catch (error) {
    setMessage("There was something wrong! please try Again");
    setStatus({loading:false, error:true});
    return;
  }
  confirm();
	};
  const modal = useRef<HTMLIonModalElement>(null);
  const input = useRef<HTMLIonInputElement>(null);

  function confirm() {
      modal.current?.dismiss(input.current?.value, 'confirm');
    
  }

  function onWillDismiss(ev: CustomEvent<OverlayEventDetail>) {
    if (ev.detail.role === 'confirm') {
      setMessage(`Hello, ${ev.detail.data}!`);
    }
  }
	return (
		<IonPage className='Profile'>
			<IonHeader>
				<IonToolbar>
					<IonButtons slot="start">
						<IonButton>
							<IonBackButton color="primary" text="" />
						</IonButton>
					</IonButtons>
				</IonToolbar>
			</IonHeader>
			<IonContent>

				<div className='topHeader'></div>

				<IonGrid>
					<IonRow className="ion-justify-content-center">
						<IonCol size="12" className="ion-justify-content-center ion-align-items-center ion-text-center">
							<IonCard className='profileHeader'>

								<IonCardContent>

									<IonRow>
										
										<IonText>
											Edit Profile Info
										</IonText>
										
									</IonRow>
								</IonCardContent>
							</IonCard>
						</IonCol>
					</IonRow>

			

					<IonRow className='profileActionContainer'>
						<IonCol size="12">
							<IonCard className='profileActionCard'>
								<IonCardContent>
								<IonAlert
                isOpen={status.error}
                onDidDismiss={() => setStatus({loading:false,error:false})}
                cssClass="my-custom-class"
                header={"Error!"}
                message={message}
                buttons={["Dismiss"]}
            />
        <IonRow>
        <IonCol  size-md="6">
            <br/>
          </IonCol>
          <IonCol  size-md="6">
            <IonAvatar className='logo'>
            <img alt="Profile Silhoutte" src={Image} onClick={()=> imgInputRef.current.click()}/>
            </IonAvatar>
          </IonCol>
          <IonCol  size-md="12">
            <br/>
          </IonCol>
        </IonRow>
            <input
                type="file"
                accept="image/*"
                ref={imgInputRef}
                onChange={handleFile}
                hidden
                disabled
                />
          <IonRow>
            <IonCol>
            <IonItem>
            {profile?.map((profile:any) => {return(
            <IonLabel position="floating" key={profile.id}>Name: {profile?.name} </IonLabel>
            )})}
            <IonInput
                type="text"
                value={text}

                placeholder="Enter Full name"
                onIonChange={(e) => setText(e.detail.value!)}
                ></IonInput>
            </IonItem>
            <IonItem lines='none'>
            <div className='editButton'> 
            <IonButton onClick={handleNameEdit}> Edit </IonButton>
            </div>
            </IonItem>
            </IonCol>
          </IonRow>
          <IonRow>
            <IonCol>
            <IonItem>
            {profile?.map((profile:any) => {return(
            <IonLabel position="floating" key={profile.id}>Age: {profile?.age}</IonLabel>
            )})}
            <IonInput
                type="number"
                value={age}

                placeholder="Enter Age"
                onIonChange={(e) => setAge(e.detail.value!)}
                >
            </IonInput>
            </IonItem>
            <IonItem lines='none'>
            <div className='editButton'> 
            <IonButton onClick={handleAgeEdit}> Edit </IonButton>
            </div>
            </IonItem>
            </IonCol>
          </IonRow>

          <IonRow>
            <IonCol>
            <IonButton id="passwordModal" expand="block">
                Change Password
              </IonButton>
              <IonModal ref={modal} trigger="passwordModal" onWillDismiss={(ev) => onWillDismiss(ev)}>
          <IonHeader>
            <IonToolbar>
              <IonButtons slot="start">
                <IonButton onClick={() => modal.current?.dismiss()}>Cancel</IonButton>
              </IonButtons>
              <IonButtons slot="end">
                <IonButton strong={true} onClick={handlePasswordChange}>
                  Confirm
                </IonButton>
              </IonButtons>
            </IonToolbar>
          </IonHeader>
          <IonContent className="ion-padding">
            <IonItem>
              <IonLabel position="floating">Enter New Pasword</IonLabel>
            <IonInput
                type="password"
                value={password}
                placeholder="Enter your password"
                required
                onIonChange={(e) => setPassword(e.detail.value!)}
                >
            </IonInput>
            </IonItem>
            <IonItem>
              <IonLabel position="floating">Confirm New Password</IonLabel>
            <IonInput
                 type="password"
                 value={confirmpassword}
                 placeholder="Confirm your password"
                 required
                 onIonChange={(e) => setConfirmpassword(e.detail.value!)}
                >
            </IonInput>
            </IonItem>
          </IonContent>
        </IonModal>
            
            </IonCol>
          </IonRow>

          
								</IonCardContent>
							</IonCard>
						</IonCol>
					</IonRow>
				</IonGrid>

			</IonContent>
		</IonPage>
	);
};

export default EditProfile;
