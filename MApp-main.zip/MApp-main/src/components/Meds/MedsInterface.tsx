
import images from '../../pages/MedicalList/image/images';
export 
const medications= [
  {
    id:"1",
    imge: images.user,
    medName: 'panadol',
    username: 'Hussain'
  },
  {
    id:"2",
    imge: images.user,
    medName: 'brufon',
    username: 'Ahmed'
  },
  {
    id:"3",
    imge: images.user,
    medName: 'Vitamins',
    username: 'You'
  },
]
