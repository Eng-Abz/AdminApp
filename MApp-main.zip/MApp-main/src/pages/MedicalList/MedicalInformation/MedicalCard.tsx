
import React from 'react'

import { 
    IonButton,
    IonCol,
    IonImg,
    IonRow,

 } from '@ionic/react'

 import './MedicalCard.css'
 import { useRef } from 'react'


import RightSideButton from '../RightSideButton/RightSideButton'
import MedicalModal from '../../../components/MedicalModal'
import Modal from '../../../components/Modal'


interface props{
    image: string|'',
    day: string | undefined,
    date: string | undefined,
    pillName: string | undefined,
    pillAmount: Number | undefined,
 }

const MedicalCard: React.FC<props> = ({image,day, date, pillName, pillAmount}) => {
    const modal = useRef<HTMLIonModalElement>(null);

  function dismiss() {
    modal.current?.dismiss();
}
  return (
        <>        
        <IonRow className='padingDate'>
            <IonCol className='DayAndDate'>
                <IonRow>
                    {day} {date}
                </IonRow>  
            </IonCol>
        </IonRow>
        
            <IonRow className='padingPillInformation'>
                <IonCol className='ion-align-self-center'  size='9'>
                        <IonRow>                            
                            <IonCol size='2'>
                                <IonRow className='pillImg'>
                                <div >
                                    <IonImg src={image}/>
                                </div>
                                </IonRow>
                            </IonCol>
                            <IonCol></IonCol>
                            <IonButton  expand="full" className='pillButton' fill='clear'>
                                <IonCol className='padingPillInformationCol'>
                                    <IonRow className='padingPillName'>
                                        {pillName}
                                    </IonRow>
                                    <IonRow>
                                        {pillAmount} pills
                                    </IonRow>   
                                </IonCol>
                            </IonButton>
                        </IonRow> 
                </IonCol>
                <IonCol className='ion-align-self-start'>
                    <IonRow className='ion-justify-content-end'>
                        <IonCol >
                            <RightSideButton />
                        </IonCol>
                    </IonRow>
                </IonCol>
            </IonRow>
        <IonButton  expand="block" className='pillButton' fill='clear' onClick={()=><Modal onDismiss={dismiss}/>}></IonButton>
        </>
  )
}

export default MedicalCard