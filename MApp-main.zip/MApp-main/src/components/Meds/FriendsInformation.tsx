
import { IonAvatar, IonButton, IonCol, IonContent, IonGrid, IonImg, IonInput, IonItem, IonLabel, IonModal, IonRow } from "@ionic/react"
import { updateProfile } from "firebase/auth";
import { doc, onSnapshot, updateDoc, deleteDoc } from "firebase/firestore";
import { getDownloadURL, listAll, ref } from "firebase/storage";
import { useEffect, useRef, useState } from "react";
import { useAuth } from "../../auth";
import { auth, db, storage } from "../../firebase";

interface Props{
    uid?: string,
    id?: string,
    image?: string,
    medName?: string,
}

const FriendsInformation: React.FC<Props> = ({uid, medName}) => {
  const [image, setImage] = useState<string>("https://ionicframework.com/docs/demos/api/avatar/avatar.svg");
  const {userId} = useAuth()
  const user = auth.currentUser;
useEffect(()=>{
  if (user?.photoURL == undefined){

  }
  let fileRef = ref(storage,`/Users/${userId}/photos/`);
  listAll(fileRef)
  .then((res) => {
    res.items.forEach((itemRef) => {
     console.log("the items in storage", itemRef.name)
     fileRef = ref(storage,`/Users/${userId}/photos/${itemRef.name}`);
    });
    getDownloadURL(fileRef)
  .then((url) => {
    setImage(url);
  })
  });
	}, []);
  if (user !== null) {
    updateProfile(user, {
      photoURL: image
    })

  };

  //useState for profile start
  const [friendName, setFriendName]= useState<number>(0)
  const profileRef = doc(db, `/Users/${uid}/profile/profile`);
  //useState for profile end
  
  useEffect(() => {
  onSnapshot(profileRef, (doc)=>{
       setFriendName(doc.get("name"))
    })
  }, []);


  //write to database section end

  //Delete from database Start
  const deleteFriendDocumnet=async() => {
    dismiss()    
  } 
 //Delete from database end

 

  const modal = useRef<HTMLIonModalElement>(null);

  function dismiss() {
    modal.current?.dismiss();
  }

  return (
    <>
      
            <IonItem detailIcon="" key={uid}>
                  <IonAvatar slot="start">
                    <IonImg src={image} />
                  </IonAvatar>
                  <IonLabel>
                    <h2>{friendName}</h2>
                    <h2 style={{color: 'gray', fontSize: 'small'}}>{medName}</h2>
                  </IonLabel>
                                
            </IonItem>
    
    </>
       
    
  )
}

export default FriendsInformation