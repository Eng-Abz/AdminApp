import { IonButton, IonGrid, IonRow, IonCol, IonAvatar } from '@ionic/react';
import { useEffect, useState } from 'react';
import { auth, storage } from '../firebase';
import { useAuth } from '../auth';
import { updateProfile } from 'firebase/auth';
import { getDownloadURL, listAll, ref } from 'firebase/storage';
import { Redirect  } from 'react-router';


const Header: React.FC = () => {
  const [image, setImage] = useState<string>("https://ionicframework.com/docs/demos/api/avatar/avatar.svg");
  const {userId} = useAuth()
  const user = auth.currentUser;
useEffect(()=>{
  
  let fileRef = ref(storage,`/Users/${userId}/photos/`);
  listAll(fileRef)
  .then((res) => {
    res.items.forEach((itemRef) => {
     console.log("the items in storage", itemRef.name)
     fileRef = ref(storage,`/Users/${userId}/photos/${itemRef.name}`);
    });
    getDownloadURL(fileRef)
  .then((url) => {
    setImage(url);
  })
  });
	}, []);
  if (user !== null) {
    updateProfile(user, {
      photoURL: image
    })

  };
  return (
  <IonGrid>
    <IonRow>
      <IonCol>
      <IonButton fill="clear" routerLink="/my/history">
              History
           </IonButton>
      </IonCol>
      <IonCol size="3">
      <IonButton fill="clear" routerLink="/my/profile">
        <IonAvatar>
          <img alt="Profile Silhouette" src={image} />
        </IonAvatar>
        </IonButton>
      </IonCol>
    </IonRow>
  </IonGrid>
  );
};
export default Header;
