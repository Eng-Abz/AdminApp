import { IonButton, IonIcon } from '@ionic/react'
import React from 'react'

import './RightSideButton.css'
import { clipboard} from 'ionicons/icons';




const RightSideButton :React.FC= () => {
  return (
    <div className='buttonQ'>
        <IonButton size='small' fill='clear' slot='end'>
            <IonIcon icon={clipboard} color={'success'} />
        </IonButton>
    </div>
  )
}

export default RightSideButton