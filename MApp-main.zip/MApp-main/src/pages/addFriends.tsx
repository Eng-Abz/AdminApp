import { IonButton, IonButtons, IonBackButton, IonCard, IonCardContent,IonSearchbar,IonItem,IonLabel,  IonCardHeader, IonCardSubtitle, IonCardTitle, IonCol, IonContent, IonGrid, IonHeader, IonIcon, IonPage, IonRow, IonText, IonToolbar, IonAvatar, IonModal, IonInput } from '@ionic/react';
import { OverlayEventDetail } from '@ionic/react/dist/types/components/react-component-lib/interfaces';

import { useRef } from 'react';

import "./addFriends.css";

const AddFriends: React.FC = () => {
	
	const handleAddFriends = async () => {

		confirm();
	};
	const modal = useRef<HTMLIonModalElement>(null);
  const input = useRef<HTMLIonInputElement>(null);

  function confirm() {
      modal.current?.dismiss(input.current?.value, 'confirm');
    
  }

  function onWillDismiss(ev: CustomEvent<OverlayEventDetail>) {
    if (ev.detail.role === 'confirm') {
      postMessage(`Hello, ${ev.detail.data}!`);
    }
  }

	return (
		<IonPage className='Profile'>
			<IonHeader>
				<IonToolbar>
					<IonButtons slot="start">
						<IonButton>
							<IonBackButton color="primary" text="" />
						</IonButton>
					</IonButtons>
				</IonToolbar>
			</IonHeader>
			<IonContent>

				<div className='topHeader'></div>

				<IonGrid>
					<IonRow className="ion-justify-content-center">
						<IonCol size="12" className="ion-justify-content-center ion-align-items-center ion-text-center">
							<IonCard className='profileHeader'>

								<IonCardContent>

									<IonRow>
										<IonCol >
										<IonButton id="addModal" expand="block">
                Add Friends
              </IonButton>
				  <IonModal ref={modal} trigger="addModal" onWillDismiss={(ev) => onWillDismiss(ev)}>
          <IonHeader>
            <IonToolbar>
              <IonButtons slot="start">
                <IonButton onClick={() => modal.current?.dismiss()}>Cancel</IonButton>
              </IonButtons>
              <IonButtons slot="end">
                <IonButton strong={true}  onClick={handleAddFriends}>
                  Confirm
                </IonButton>
              </IonButtons>
            </IonToolbar>
          </IonHeader>
          <IonContent className="ion-padding">
			 <IonCard className='profileHeader'>

<IonCardContent>

	<IonRow>
		<IonCol >
		<IonSearchbar  placeholder="Search Friend by Email">
		</IonSearchbar>
		</IonCol>
	</IonRow>
</IonCardContent>
</IonCard>
          </IonContent>
        </IonModal>
										</IonCol>
									</IonRow>
								</IonCardContent>
							</IonCard>
						</IonCol>
					</IonRow>

				

					<IonRow className='profileActionContainer'>
						<IonCol size="6">
						<IonRow className="ion-justify-content-between">
							<IonCard className='profileActionCard'>	
							<IonCardContent>
								<IonAvatar slot="start">
									<img alt="Silhouette of a person's head" src="https://ionicframework.com/docs/img/demos/avatar.svg" />
								</IonAvatar>
								<IonLabel>Abdulaziz Mohameden</IonLabel>
							</IonCardContent>	
							</IonCard>
							</IonRow>
						</IonCol>
						<IonCol size="6">
						<IonRow className="ion-justify-content-between">
							<IonCard className='profileActionCard'>	
							<IonCardContent>
								<IonAvatar slot="start">
									<img alt="Silhouette of a person's head" src="https://ionicframework.com/docs/img/demos/avatar.svg" />
								</IonAvatar>
								<IonLabel>Alhousin Albar</IonLabel>
							</IonCardContent>	
							</IonCard>
							</IonRow>
						</IonCol>
					</IonRow>

					<IonRow className='profileActionContainer'>
						<IonCol size="6">
						<IonRow className="ion-justify-content-between">
							<IonCard className='profileActionCard'>	
							<IonCardContent>
								<IonAvatar slot="start">
									<img alt="Silhouette of a person's head" src="https://ionicframework.com/docs/img/demos/avatar.svg" />
								</IonAvatar>
								<IonLabel>Abdulaziz Mohameden</IonLabel>
							</IonCardContent>	
							</IonCard>
							</IonRow>
						</IonCol>
						<IonCol size="6">
						<IonRow className="ion-justify-content-between">
							<IonCard className='profileActionCard'>	
							<IonCardContent>
								<IonAvatar slot="start">
									<img alt="Silhouette of a person's head" src="https://ionicframework.com/docs/img/demos/avatar.svg" />
								</IonAvatar>
								<IonLabel>Alhousin Albar</IonLabel>
							</IonCardContent>
							</IonCard>
							</IonRow>
						</IonCol>
					</IonRow>


				</IonGrid>

			</IonContent>
		</IonPage>
	);
};

export default AddFriends;
