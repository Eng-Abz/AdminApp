import { LocalNotifications } from '@capacitor/local-notifications';


class Notifications {
  public async scheduleEveryDay(hour: number,minute: number, perDay: number, name:string) {
    try {
      console.log("the per day value is", perDay);
      // Request/ check permissions
      if (!(await LocalNotifications.requestPermissions)) return;
      
      // Clear old notifications in prep for refresh (OPTIONAL)
      const pending = await LocalNotifications.getPending();
      if (pending.notifications.length > 0)
      await LocalNotifications.cancel(pending);
      
      await LocalNotifications.createChannel({
        id:'everyday',
        name:'everyday',
        description:'everyday channel',
        sound: 'clockbeep.wav'
      });
      
        await LocalNotifications.schedule({
          notifications: [{
            title: 'Pill time!',
            body: `please take your ${name} pills`,
            id: Math.random(),
            smallIcon: "ic_stat_pill_time",
            channelId:'everyday',
            schedule: {
              on:{
                 hour,
                 minute
              }
            }
          }]
        });
      
    } catch (error) {
      console.error(error);
    }
  }
  
  public async scheduleEveryWeek(day:number,hour: number,minute: number, perDay: number, name:string) {
    try {
      // Request/ check permissions
      if (!(await LocalNotifications.requestPermissions)) return;
      
      // Clear old notifications in prep for refresh (OPTIONAL)
      const pending = await LocalNotifications.getPending();
      if (pending.notifications.length > 0)
      await LocalNotifications.cancel(pending);
      
      await LocalNotifications.createChannel({
        id:'everyweek',
        name:'everyweek',
        description:'everyweek channel',
        sound: 'clockbeep.wav'
      });
      
      if(perDay === 1){
      await LocalNotifications.schedule({
        notifications: [{
          title: 'Pill time!',
          body: `please take your ${name} pills`,
          id: Math.random(),
          smallIcon: "ic_stat_pill_time",
          channelId:'everyweek',
          schedule: {
            every:"week",
            repeats:true,
            count: 1,
            on:{
               day,
               hour,
               minute
            },
          }
        }]
      });
    }
      else{
        await LocalNotifications.schedule({
          notifications: [{
            title: 'Pill time!',
            body: `please take your ${name} pills`,
            id: Math.random(),
            smallIcon: "ic_stat_pill_time",
            channelId:'everyday',
            schedule: {
              every:"day",
              count: perDay,
              repeats:true,
              on:{
                 day,
                 hour,
                 minute
            },
          }
          }]
        });
      }
    } catch (error) {
      console.error(error);
    }
  }
  public async scheduleTrial(name:string){
    try {
      // Request/ check permissions
      if (!(await LocalNotifications.requestPermissions)) return;
      
      // Clear old notifications in prep for refresh (OPTIONAL)
      const pending = await LocalNotifications.getPending();
      if (pending.notifications.length > 0)
      await LocalNotifications.cancel(pending);
      
      await LocalNotifications.createChannel({
        id:'test',
        name:'test',
        description:'test channel',
        sound: 'clockbeep.wav'
      });
      await LocalNotifications.schedule({
        notifications: [{
          title: 'Pill time!',
          body: `please take your ${name} pills`,
          id: Math.random(),
          smallIcon: "ic_stat_pill_time",
          channelId:'test'
        }]
      });
    }
  catch (error) {
    console.error(error);
    }
  }
}

export default new Notifications()