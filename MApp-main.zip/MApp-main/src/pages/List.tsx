import {
  IonContent,
  IonPage, 
} from '@ionic/react';
import { collection, onSnapshot } from 'firebase/firestore';
import { useEffect, useState } from 'react';
import { useAuth } from '../auth';

import Header from '../components/Header';
import Friends from '../components/Meds/Friends';
import { db } from '../firebase';
import './List.css'

const List: React.FC = () => {
  const { userId } = useAuth();
	
  const [friends, setFriends] = useState<any[]>();
 
	
	const togetherRef = collection(db, `/Users/${userId}/together/`);

	useEffect(()=>{
    
	const getMedicationDat = async () => {    
    onSnapshot(togetherRef, (doc) => {
      setFriends(doc.docs.map(doc => ({...doc.data(), id: doc.id})))
  });
}
		getMedicationDat()
	}, []); 
	
  return (
    <IonPage>
      <IonContent fullscreen>        
       
          <Header/>
          
          <h1 className='title'>Friends List</h1>
          
          {friends?.map(friend => {
            return(
              <div key={friend.id} style={{paddingBottom: 10}}>
              <Friends  id={friend.togID} />
              </div>
            )
          })}         
      </IonContent>
    </IonPage>
  );
};

export default List;
