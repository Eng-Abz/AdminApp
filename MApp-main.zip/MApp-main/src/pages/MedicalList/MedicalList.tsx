
import { IonGrid } from '@ionic/react';
import images from './image/images';
import './MedicalList.css'
import MedicalCard2 from './MedicalInformation/MedicalCard2';
import { useAuth } from '../../auth';
import { 
  useEffect, 
  useState 
} from 'react';
import { db } from '../../firebase';
import { 
  collection,  
  onSnapshot
} from 'firebase/firestore';



const MedicalList = () => {
  const { userId } = useAuth();
	
  const [medication, setMedication] = useState<any[]>();
 
	
	const medicationRef = collection(db, `/Users/${userId}/medications/`);

	useEffect(()=>{
    
	const getMedicationData = async () => {    
    onSnapshot(medicationRef, (doc) => {
      setMedication(doc.docs.map(doc => ({...doc.data(), id: doc.id})))
  });
}    
		getMedicationData()
	}, []);

  return (
    <>          {medication?.map((medicine : any)=> {
          return(
              <MedicalCard2 key={medicine.id} id={medicine.id} image={images.user} medName={medicine.name} medAmount={medicine.instructed} day={"Fridy"} date={'14/10/2022'} instructed={medicine.instructed} status={medicine.taken}/>
          )
          })}
    </>
  );
}

export default MedicalList;
