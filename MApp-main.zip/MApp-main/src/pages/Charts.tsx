import {
IonContent,
IonToolbar,
IonPage,
IonDatetime,
IonGrid,
IonRow,
IonCol,
IonButton,
  } from '@ionic/react';

import './Charts.css';
import Header from '../components/Header';
import HistoryPage from './HistoryPage/HistoryPage';

const Charts: React.FC = () => {
  return (
  <IonPage>
    <IonContent>
      <IonGrid className="customGrid">
        <IonToolbar color="primary">
          <Header/>
        </IonToolbar>
        <IonRow style={{backgroundColor: "#198032"}}>
          <IonCol>
          <IonButton className="customButton" expand="full" routerLink="#">
          Charts
          </IonButton>
          </IonCol>
          <IonCol>
          <IonButton className="customButton" expand="full" routerDirection='forward' routerLink="/my/list">
            List
          </IonButton>
          </IonCol>

        </IonRow>
      </IonGrid>
      <HistoryPage/>
    </IonContent>
  </IonPage>
);
};


export default Charts;
