import { Redirect, Route } from 'react-router-dom';
import {
  IonIcon,
  IonRouterOutlet,
  IonTabBar,
  IonTabButton,
  IonTabs,
  IonFabButton,
} from '@ionic/react';

import { useAuth } from '../auth';


import Charts from '../pages/Charts';
import EditProfile from '../pages/editProfile/editProfile';
import Home from '../pages/Home';
import List from '../pages/List';
import FormPage from '../pages/FormPage';
import {statsChart, add, peopleOutline } from 'ionicons/icons';
import PillPage from '../pages/pillPage';
import Profile from '../pages/Profile';
import HistoryPage from '../pages/HistoryPage/HistoryPage';
import AddFriends from '../pages/addFriends';

const AppTabs: React.FC = () => {
  const {loggedIn} = useAuth();
  if(!loggedIn){
    return <Redirect to="/welcome" />
  }
return (
   <IonTabs>
   <IonRouterOutlet>
    
     <Route exact path="/my/addFriends"><AddFriends />  </Route>
     <Route exact path="/my/charts"><Charts />   </Route>
     <Route exact path="/my/editProfile"><EditProfile />   </Route>
     <Route exact path="/my/formPage"> <FormPage />  </Route>
     <Route exact path="/my/home"><Home />  </Route>
     <Route exact path="/my/list"><List />   </Route>
     <Route exact path="/my/pillpage/:id"><PillPage />   </Route>
     <Route exact path="/my/profile"><Profile />  </Route>
     <Route exact path="/my/history"><HistoryPage/>  </Route>
      

   </IonRouterOutlet>
   
   <IonTabBar slot="bottom">
     <IonTabButton tab="home" href="/my/home">
       <IonIcon icon={peopleOutline} />
     </IonTabButton>

     <IonTabButton tab="FormPage" href="/my/formPage">
       <IonFabButton>

         <IonIcon size="large" icon={add} />

       </IonFabButton>
     </IonTabButton>

     <IonTabButton tab="List" href="/my/list">
       <IonIcon icon={statsChart} />
     </IonTabButton>

   </IonTabBar>
 </IonTabs>
);
};

export default AppTabs;
