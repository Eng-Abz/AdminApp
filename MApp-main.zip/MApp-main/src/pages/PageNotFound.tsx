import { 
   IonContent, 
   IonPage, 
 } from '@ionic/react';

 
 
 
 const PageNotFound: React.FC = () => {
   return (
     <IonPage>
       <IonContent fullscreen>
      Page Not Found!
       </IonContent>
     </IonPage>
   );
 };
 
 export default PageNotFound;