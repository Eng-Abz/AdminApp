import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  plugins: {
    LocalNotifications: {
      smallIcon: "ic_stat_pill_time",
      iconColor: "#61A83C",
      sound: "clockbeep.wav",
    },
  },
  appId: 'com.h_a.pilltime',
  appName: 'Pill Time',
  webDir: 'build',
  bundledWebRuntime: false,
};

export default config;
