import { 
  IonBackButton,
  IonButton,
  IonButtons,
  IonContent, 
  IonHeader, 
  IonPage,
  IonText,
  IonToolbar, 
} from '@ionic/react';
import { medications } from '../components/Meds/MedsInterface';
import Header from '../components/Header';
import { useParams } from 'react-router';

interface RouteParams{
  id: string
}
const PillPage: React.FC = () => {
  const {id} = useParams<RouteParams>();
  const pillInfo = medications.find((pillInfo) => pillInfo.id === id);
  return (
    <IonPage>
      <IonHeader>
				<IonToolbar color="clear">
					<IonButtons slot="start">
						<IonButton>
							<IonBackButton color="primary" text="" />
						</IonButton>
					</IonButtons>
				</IonToolbar>
			</IonHeader>
      <IonContent fullscreen>
      <Header/>
          <br/>
          <br/>
          <br/>
          <IonText>
          Pill Name:  {pillInfo?.medName}
          </IonText>
          <br/>
          <IonText>
          {pillInfo?.username}
          </IonText>
      </IonContent>
    </IonPage>
  );
};

export default PillPage;
