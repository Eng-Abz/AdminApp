import {
  IonRow,
  IonCol,
  IonItemGroup,
  IonList,
   } from '@ionic/react';
import { collection, onSnapshot } from 'firebase/firestore';
import { useEffect, useState } from 'react';
import { db } from '../../firebase';
import FriendsInformation from './FriendsInformation';

interface TOTogether {
    id?: string
}


const Friends: React.FC<TOTogether> = ({id}) => {

  const [medication, setMedication] = useState<any[]>();
 
	
	const medicationRef = collection(db, `/Users/${id}/medications/`);

	useEffect(()=>{
    
	const getMedicationDat = async () => {    
    onSnapshot(medicationRef, (doc) => {
      setMedication(doc.docs.map(doc => ({...doc.data(), id: doc.id})))
  });
}
		getMedicationDat()
	}, []); 

  return(


      <IonRow>
        <IonCol>
        <IonItemGroup>
        <IonList>
          {medication?.map((medication)=>
          {
            return(
            <FriendsInformation key={medication.id} uid={id} image={medication.imge} medName={medication.name}/>
            )
          })}

         </IonList>
       </IonItemGroup>

        </IonCol>
      </IonRow>

  );
}
export default Friends;
