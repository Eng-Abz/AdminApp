
import { IonAvatar, IonButton, IonCol, IonContent, IonGrid, IonImg, IonInput, IonItem, IonLabel, IonModal, IonRow } from "@ionic/react"
import { doc, onSnapshot, updateDoc, deleteDoc } from "firebase/firestore";
import { useEffect, useRef, useState } from "react";
import { useAuth } from "../../../auth";
import { db } from "../../../firebase";

import './MedicalCard2.css'

interface Props{
    id: string,
    image: string,
    medName: string,
    medAmount: number,
    day: string,
    date: string,
    instructed: number,
    status: boolean,
}

const MedicalCard2: React.FC<Props> = ({id,image, medName, medAmount, date, day, instructed, status}) => {
  const { userId } = useAuth(); 

  //useState for medictaions start
  const [medicationStatus ,setMedicationStatus] = useState(status)
  const [newInstructed, setNewInstructed] = useState<number>(instructed)
  const [disableTaken, setDisableTaken] = useState<boolean>(status)
  const [disableNotTaken, setDisableNotTaken] = useState<boolean>(!(status))
  const medRef= doc(db,`/Users/${userId}/medications/${medName}`)

  //useState for medictaions end

  //useState for profile start
  const [data, setData]= useState<number>(0)
  const profileRef = doc(db, `/Users/${userId}/profile/profile`);
  //useState for profile end
  
  useEffect(() => {
  onSnapshot(profileRef, (doc)=>{
       setData(doc.get("takenPills"))
    })
  }, []);

  
  


  //write to database section start

  const taken = async (e: any) => {
    setMedicationStatus(true);
    setDisableTaken(true)
    setDisableNotTaken(false)
    dismiss()
    let numPill = newInstructed -1
    setNewInstructed(numPill)
  
    const medData = {
      taken: true,
      instructed: numPill
    }

    const profileData={
          takenPills: data + 1
    }
    
    await updateDoc(medRef,medData)
    await updateDoc(profileRef,profileData)
  };
  const notTaken = async (e: any) => {
    setMedicationStatus(false);
    setDisableTaken(false)
    setDisableNotTaken(true)
    dismiss()
    let numPill = newInstructed +1
    setNewInstructed(numPill)
    const medData = {
      taken: false,
      instructed:  numPill
    }
    const profileData={
          takenPills: data -1
    }
    await updateDoc(medRef,medData)
    await updateDoc(profileRef,profileData)
  };



  const handleUpdatePillAmount= async (detail: any) => {
      const UpdatedPillAmount={
      instructed: newInstructed,
    }
    await updateDoc(medRef,UpdatedPillAmount)
  }
  
  //write to database section end

  //Delete from database Start
  const deleteDocumnet=async() => {
    deleteDoc(medRef)
    dismiss()    
  } 
 //Delete from database end

 

  const modal = useRef<HTMLIonModalElement>(null);

  function dismiss() {
    modal.current?.dismiss();
  }

  return (
    <>
      <div className="container">
        <IonGrid>
        <IonRow>
          <IonCol size="1">
          </IonCol>
          <IonCol size="11">
          <div className="dateAndDay">
            <IonLabel>{date} {day} </IonLabel>
          </div>
          </IonCol>
        </IonRow>
        <IonRow>
          <IonCol size="12">
            <IonItem button detailIcon="" key={id} lines="none" id={`example-modal/${medName}`} >
                  <IonAvatar slot="start">
                    <IonImg src={image} />
                  </IonAvatar>
                  <IonLabel>
                    <h2>{medName}</h2>
                    <h2 style={{color: 'gray', fontSize: 'small'}}>{medAmount} pills</h2>
                  </IonLabel>
                  {
                    medicationStatus ? <div className="circleTrue"></div> : <div className="circleFalse"></div>
                  }
                  
            </IonItem>
          </IonCol>
        </IonRow>
        
        
        </IonGrid>
    </div>
    <IonModal id="example-modal" ref={modal} trigger={`example-modal/${medName}`}>
    <IonContent class="ion-padding">
          <IonGrid>
            <IonRow>
            <IonCol size="1">
              </IonCol>             
              <IonCol size="3">                  
                  <IonButton slot="" size="default" onClick={taken} disabled={disableTaken} >taken</IonButton>
              </IonCol>
             
              <IonCol  size="3">                  
                  <IonButton color="warning" size="default" onClick={notTaken} disabled={disableNotTaken} >not taken</IonButton>
              </IonCol>
              <IonCol size="1">
              </IonCol>
              <IonCol size="3">
                <IonButton color="danger" onClick={deleteDocumnet} size="default">delete</IonButton>
              </IonCol>
            </IonRow>
            <IonRow>
              <IonCol size="12">
                <IonRow>
                  <IonCol size="12">
                      <IonLabel class="text"> Pill Amount :</IonLabel>
                  </IonCol>
                </IonRow>
                <IonRow>
                  <IonCol size="10">
                    <IonInput 
                    placeholder={`${medAmount}`}
                    type="number"
                    onIonChange={(details : any)=> setNewInstructed(details.target.value)}  
                   />
                  </IonCol>
                  <IonCol size="2">
                    <IonButton 
                    size="small"  
                    fill="clear"
                    onClick={handleUpdatePillAmount}
                    >update</IonButton>
                  </IonCol>
                </IonRow>
              </IonCol>
            </IonRow>
          </IonGrid>
                      
        </IonContent>
    </IonModal>
   
    </>
       
    
  )
}

export default MedicalCard2