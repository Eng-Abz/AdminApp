import { 
  IonButton,
  IonContent, 
  IonPage,
} from '@ionic/react';
import Meds from '../components/Meds/Friends';
import Header from '../components/Header';
import MedicalList from './MedicalList/MedicalList';
import './Home.css'
import { Redirect } from 'react-router';


const Home: React.FC = () => {
  const med ="panadol";
  return (
    <IonPage>
      <IonContent fullscreen ion-padding-none ion-margin-none>
      <Header/>
         <MedicalList/>
      </IonContent>
    </IonPage>
  );
};

export default Home;
