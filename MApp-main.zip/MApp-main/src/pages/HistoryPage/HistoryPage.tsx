import { IonButton, IonContent, IonHeader, IonPage, IonToolbar } from '@ionic/react';
import React from 'react';
import HistoryTable from './HistoryTable/HistoryTable';

interface Props {

}

const HistoryPage: React.FC<Props> = (props) => {
  return (
    <>
    <IonPage>
        <IonHeader>
            <IonToolbar>
            <div className='headerText'>History Page</div>
            <IonButton slot='end'>PDF</IonButton>
            </IonToolbar>
        </IonHeader>
        <IonContent >
            <HistoryTable />
        </IonContent>
    </IonPage>
    </>
  );
}

export default HistoryPage;
