
import { collection, onSnapshot } from 'firebase/firestore';
import { useEffect, useState } from 'react';
import { useAuth } from '../../../auth';
import { db } from '../../../firebase';

import './HistoryTable.css';
const HistoryTable = () => {
    const Medicines=[
    {   key: 1,
        name: 'panadol'},
    {   key:2,
        name: "panadol"},
    {   key:3,
            name: "phiphadol"},
    

    ]

    const MedicalsSurgicals=[
        {
            key: 1,
            history: 'nee surgary'
        }
    ]
    const { userId } = useAuth();
	
    const [medication, setMedication] = useState();
 
	
	const medicationRef = collection(db, `/Users/${userId}/medications/`);

    useEffect(()=>{
    
        const getMedicationData = async () => {    
            onSnapshot(medicationRef, (doc) => {
              setMedication(doc.docs.map(doc => ({...doc.data(), id: doc.id})))
      });
    }    
            getMedicationData()
        }, []);


  return (
    <div className="container">
       <table>
            <tr>
                <th>Name :</th>
                <td>Abdullah Meir</td>
            </tr>
            <tr>
                <th>Age :</th>
                <td>22</td>
            </tr>
            <tr>
                <th>Medical Surgical : History </th>
                <td>
                    {MedicalsSurgicals.map((MedicalSurgical)=>{
                    return(<tr key={MedicalSurgical.key} className="medicineRow"><td>{MedicalSurgical.history}</td></tr>)})}
                </td>
            </tr>
            <tr>
                <th>Medications :</th>
                <td>
                    {Medicines.map((medicine)=>{
                    return(<tr key={medicine.key} className="medicineRow"><td>{medicine.name}</td></tr>)})}
                </td>
            </tr>
            <tr>
                <th>Alargies</th>
                <td>Francisco Chang</td>
            </tr>
        </table> 
    </div>
  );
}

export default HistoryTable;
