import { Redirect } from 'react-router-dom';
import React, { useState } from 'react';
import { IonContent, IonItem, IonLabel, IonInput, IonButton, IonIcon, IonAlert, IonPage, IonGrid, IonRow, IonCol, IonLoading, IonAvatar } from '@ionic/react';

import { useAuth } from '../auth';
import { login } from '../firebase';
import "./auth.css";


function validateEmail(email: string) {
    const re = /^((?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\]))$/;
    return re.test(String(email).toLowerCase());
}
const Login: React.FC = () => {
  
  const { loggedIn } = useAuth();
  const [email, setEmail] = useState<string>("");
  const [password, setPassword] = useState<string>("");
  const [status, setStatus] = useState({ loading: false, error: false});
  const [message, setMessage] = useState<string>("");
  
  
  
  const loginHandler = async () => {
    if ((!email) || validateEmail(email) === false) {
      setMessage("Please enter a valid email");
      setStatus({loading:false, error:true});
      return;
  }
  if (!password || password.length < 8) {
      setMessage("Please enter a valid password");
      setStatus({loading:false, error:true});
      return;
  }
    try {
      setStatus({loading:true, error:false});
      await login( email, password);

    } catch (error) {
      setMessage("The email address or password you entered is invalid");
      setStatus({loading:false, error:true});
    }
    
  };

  if(loggedIn){
    return <Redirect to="/my/home" />;
  } 
  return (
    <IonPage>
      <IonContent fullscreen className="ion-padding ion-text-center">
        <IonGrid>
        <IonRow>
          <IonCol>
            <IonAlert
                isOpen={status.error}
                onDidDismiss={() => setStatus({loading:false, error:false})}
                cssClass="my-custom-class"
                header={"Error!"}
                message={message}
                buttons={["Dismiss"]}
            />
          </IonCol>
        </IonRow>
        <IonRow>
        <IonCol>
        <br/> <br/>
        </IonCol>
        </IonRow>
        <IonRow>
          <IonCol  size-md="6">
            <br/>
          </IonCol>
          <IonCol  size-md="6" className=''>
            <IonAvatar className='logo'>
            <img alt="logo" src="/assets/Logo.svg"/>
            </IonAvatar>
          </IonCol>
          <IonCol  size-md="12">
            <br/>
          </IonCol>
        </IonRow>
          <IonRow>
            <IonCol>
            <IonItem>
              <IonLabel position="floating"> Email</IonLabel>
              <IonInput
                type="email"
                value={email}
                required
                onIonChange={(e) => setEmail(e.detail.value!)}
                >
              </IonInput>
            </IonItem>
            </IonCol>
          </IonRow>

          <IonRow>
            <IonCol>
            <IonItem>
              <IonLabel position="floating"> Password</IonLabel>
              <IonInput
                type="password"
                value={password}
                required
                onIonChange={(e) => setPassword(e.detail.value!)}
                >
              </IonInput>
            </IonItem>
            </IonCol>
          </IonRow>
          <IonRow>
            <IonCol>
              <p style={{ fontSize: "small" }}>
                  By clicking LOGIN you agree to our <a href="#">Policy</a>
              </p>
              <IonButton expand="block" onClick={loginHandler}>Login</IonButton>
              <p style={{ fontSize: "medium" }}>
                  Don't have an account? <a href="register">Sign up!</a>
              </p>

            </IonCol>
          </IonRow>
        </IonGrid>
        <IonLoading isOpen = {status.loading}/>
      </IonContent>
    </IonPage>
  );
};

export default Login;
